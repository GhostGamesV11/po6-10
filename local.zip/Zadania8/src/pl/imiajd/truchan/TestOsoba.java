package pl.imiajd.truchan;

import java.time.LocalDate;

public class TestOsoba {
    public void main(String[] args)
    {
        String[] imiona= new String[2];
        imiona[0]="Aleksander";
        imiona[1]="Klemens";
        LocalDate data= LocalDate.of(2021,10,10);




    }
}
