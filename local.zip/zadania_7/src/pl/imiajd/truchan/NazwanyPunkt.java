package pl.imiajd.truchan;

public class NazwanyPunkt {

}
