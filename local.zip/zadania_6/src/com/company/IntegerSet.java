package com.company;

import java.util.ArrayList;

public class IntegerSet {
    boolean list[]= new boolean[100];
    public IntegerSet(){};

    public static void union(IntegerSet zbior1,IntegerSet zbior2)
    {
        IntegerSet x=new IntegerSet();
        for(int i=0;i<zbior1.list.length;i++)
        {
            if(zbior1.list[i]||zbior2.list[i])
            {

            }
        }
    }
    public static void intersection(IntegerSet zbior1,IntegerSet zbior2)
    {
        IntegerSet x=new IntegerSet();
        for(int i=0;i<zbior1.list.length;i++)
        {
            if(zbior1.list[i]&&zbior2.list[i])
            {

            }
        }
    }

    public void insertElement(int k)
    {
        this.list[k]=true;

    }
    public void deleteElement(int k)
    {
        this.list[k]=false;

    }
    public String toString()
    {
        StringBuffer wynik=new StringBuffer();
        for(int i=0;i<list.length;i++)
        {
            wynik.append(list[i]).append(" ");
        }
        return wynik.toString();
    }
    public boolean equals(IntegerSet zbior)
    {
        IntegerSet y=new IntegerSet();
        for(int i=0;i<zbior.list.length;i++)
        {
            if(list[i]!=zbior.list[i])
            {
                return false;
            }

        }
        return true;
    }
}
